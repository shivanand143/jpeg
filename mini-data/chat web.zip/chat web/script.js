const chatBox = document.querySelector('.chat-box');
const chatMessages = document.querySelector('.chat-messages');
const chatInput = document.querySelector('.chat-input');
const chatSend = document.querySelector('.chat-send');

chatSend.addEventListener('click', sendMessage);

function sendMessage() {
    const message = chatInput.value;
    const messageElement = document.createElement('div');
    messageElement.classList.add('message');
    messageElement.textContent = message;
    chatMessages.appendChild(messageElement);
    chatInput.value = '';
}
